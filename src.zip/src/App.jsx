import React,{Component} from "react";//zeby dodac class app trzeba dac ten Component
import Countdown from "./Countdown";

class App extends Component {
  //caloksztalt funkcji
  constructor() {
    super();
    this.state = {
      //tabice oraz obiekt
      events: [
        {id: 0,name: "śniadanie",time:"7:00"},
        {id: 1,name: "obiad",time:"15:00"},
        {id: 2,name: "kolacja",time:"15:00"},
      ]
    };
  }
  render() {
    const events = this.state.events.map(el => {
      return <Countdown name={el.name} time={el.time} />;
    });
    return (
      <div>
        {events}
      </div>
    );
  }
}
/*
const App = () => (
  <div>
    <Countdown name="śniadanie" time="07:00"/>
    <Countdown name="obiad" time="15:00"/> 
  </div>
);
*/
export default App;