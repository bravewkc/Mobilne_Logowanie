import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

// Tworzenie korzenia aplikacji
const root = ReactDOM.createRoot(document.getElementById('root'));

// Renderowanie aplikacji
root.render(<App />);